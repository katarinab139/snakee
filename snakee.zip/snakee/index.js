'use strict'

const express = require('express');

const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server)

const port = process.env.PORT || 7003;

server.listen(port, () => console.log(`listening on port ${port}`));
app.use(express.static('public'));

io.on('connection', socket => {
    console.log('connected');
    socket.on("move", data => {
        socket.broadcast.emit("move", data);
    })
    socket.on("eat", data => {
        socket.broadcast.emit("eat", data);
    })
})

