import { getInputDirection } from "./input.js";
import { getRandomFoodPosition } from './food.js'

const socket = io();
socket.on("connect", () => {
  console.log(socket.id)
});

socket.on("move", data => {drawMoveWhileRecieving(data.snakeBody, data.newSegments, data.foodPos)})


function drawMoveWhileRecieving(body, segments, food){
  snakeBody[0].x = body[0].x;
  snakeBody[0].y = body[0].y;
  newSegments = segments;
  //drawSegments();
  for (let i = 0; i < newSegments; i++) {
    snakeBody.push({ ...snakeBody[snakeBody.length-1] })
  }
  newSegments = 0
  foodPos = food;
}

export const SNAKE_SPEED = 5
const snakeBody = [{ x: 1, y: 1 }]
let newSegments = 1
let foodPos = getRandomFoodPosition()

export function update() {
  const inputDirection = getInputDirection()
  for (let i = snakeBody.length - 2; i >= 0; i--) {
    snakeBody[i + 1] = { ...snakeBody[i] }
  }

  snakeBody[0].x += inputDirection.x
  snakeBody[0].y += inputDirection.y
  if (onSnake(foodPos)) {
    expandSnake()
    foodPos = getRandomFoodPosition()
  }

  socket.emit("move", {snakeBody, newSegments, foodPos})
  //drawSegments()
  for (let i = 0; i < newSegments; i++) {
    snakeBody.push({ ...snakeBody[snakeBody.length-1] })
  }
  newSegments = 0

  window.localStorage.setItem('highscore', JSON.stringify({ score: highscore}));

  let score = window.localStorage.getItem('highscore')

  if(score){
    let scoreObj = JSON.parse(score);
    console.log(scoreObj.score);
  }


}

export function draw(gameBoard) {
  snakeBody.forEach(segment => {
    const snakeElement = document.createElement('div')
    snakeElement.style.gridRowStart = segment.y
    snakeElement.style.gridColumnStart = segment.x
    snakeElement.classList.add('snake')
    gameBoard.appendChild(snakeElement)
    snakeElement.style.color = 'black'

    //draw food
    const foodElement = document.createElement('div')
    foodElement.style.gridRowStart = foodPos.y
    foodElement.style.gridColumnStart = foodPos.x
    foodElement.classList.add('food')
    gameBoard.appendChild(foodElement)
  })
}

export function expandSnake() {
  newSegments = newSegments+1
  highscore += 100
}

export function onSnake(position, { ignoreHead = false } = {}) {
  return snakeBody.some((segment, index) => {
    if (ignoreHead && index === 0) return false
    return equalPositions(segment, position)
  })
}

export function getSnakeHead() {
  return snakeBody[0]
}

export function snakeIntersection() {
  return false;
  //return onSnake(snakeBody[0], { ignoreHead: true })
}

function equalPositions(pos1, pos2) {
  return pos1.x === pos2.x && pos1.y === pos2.y
}

function drawSegments() {
  for (let i = 0; i < newSegments; i++) {
    snakeBody.push({ ...snakeBody[snakeBody.length-1] })
  }
  newSegments = 0
}

let highscore = 0

export function drawHighscore(){
  return highscore;

}